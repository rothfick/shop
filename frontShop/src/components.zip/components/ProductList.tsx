import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { getProducts } from '../services/productService';
import { Product } from '../types/Product';

const ProductList: React.FC = () => {
    const [products, setProducts] = useState<Product[]>([]);

    useEffect(() => {
        getProducts()
            .then(response => setProducts(response))
            .catch(error => console.error('Error fetching products:', error));
    }, []);

    return (
        <div>
            <h1>Product List</h1>
            <motion.ul
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5 }}
            >
                {products.map((product) => (
                    <motion.li
                        key={product.id}
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                    >
                        {product.name} - {product.price}
                    </motion.li>
                ))}
            </motion.ul>
        </div>
    );
};

export default ProductList;
